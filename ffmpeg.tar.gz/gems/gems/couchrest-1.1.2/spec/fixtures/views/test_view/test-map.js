function(doc) {
  emit(null, null);
};