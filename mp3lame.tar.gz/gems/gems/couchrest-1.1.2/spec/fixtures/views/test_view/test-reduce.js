function(ks,vs,co) {
  return vs.length;
};